export type AlertMessages = {
  close: string;
};
